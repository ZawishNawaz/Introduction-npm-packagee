#! /usr/bin/env node
import chalk from 'chalk';
import inquirer from 'inquirer';

async function introduction() {
    const response = await inquirer.prompt([
        {
            type: 'input',
            name: 'name',
            message: 'What is your name?',
        },
        {
            type: 'number',
            name: 'age',
            message: 'How old are you?',
        },
        {
            type: 'input',
            name: 'gmail',
            message: 'What is your Gmail address?',
        },
    ]);

    console.log(chalk.green(`My name is ${response.name}`));
    console.log(chalk.green(`My age is ${response.age}`));
    console.log(chalk.green(`My gmail address is ${response.gmail}`));
}

introduction();
